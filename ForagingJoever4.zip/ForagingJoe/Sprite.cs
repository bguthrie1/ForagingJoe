﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Numerics;


namespace ForagingJoe
{
    public class Sprite : GameObject
    {
        // sprite objects have velocity and location, as well as a size
        public PointF Velocity;
        public PointF Location;
        public SizeF Size;
        // the current frame refers to the frame in the sprite itself, not the game frames
        public int CurrentFrame;

        // get a list of frames from the bitmap file
        protected List<Bitmap> _frames = new List<Bitmap>();
        protected GameState _gameState;


        public Sprite(GameState gameState, float x, float y, string filename)
        {
            //add the bitmap to the frames list
            _frames.Add(new Bitmap(filename));

            //Set the location and use the height and width from the 1st frame
            initialize(gameState, x, y, _frames[0].Width, _frames[0].Height);

        }

        public Sprite(GameState gameState, float x, float y, string filename1, string filename2)
        {
            //Load the 2 animation frames
            _frames.Add(new Bitmap(filename1));
            _frames.Add(new Bitmap(filename2));

            initialize(gameState, x, y, _frames[0].Width, _frames[0].Height);
        }

        private void initialize(GameState gameState, float x, float y, float width, float height)
        {
            _gameState = gameState;
            Location.X = x;
            Location.Y = y;
            Size.Width = width;
            Size.Height = height;
            CurrentFrame = 0;
        }

        public override void Update(double gameTime, double elapsedTime)
        {
            //Move the sprite
            Location.X += Velocity.X * (float)elapsedTime;
            Location.Y += Velocity.Y * (float)elapsedTime;

        }

        public override void Draw(Graphics graphics)
        {
            //Draw the correct frame at the current point
            graphics.DrawImage(_frames[CurrentFrame], Location.X, Location.Y, Size.Width, Size.Height);
        }

        // There is something wrong with this collision check. I may have to tweak it.

        public static bool Collision(Sprite sprite1, Sprite sprite2)
        {
            return !(sprite1.Location.X > sprite2.Location.X + sprite2.Size.Width
                    || sprite1.Location.X + sprite1.Size.Width < sprite2.Location.X
                    || sprite1.Location.Y > sprite2.Location.Y + sprite2.Size.Height
                    || sprite1.Location.Y + sprite1.Size.Height < sprite2.Location.Y);
        }

        public static bool CollisionTop(Sprite sprite1, Sprite sprite2)
        {
            return !(sprite1.Location.Y > sprite2.Location.Y + sprite2.Size.Height);
        }

        public static bool CollisionBottom(Sprite sprite1, Sprite sprite2)
        {
            return !(sprite1.Location.Y + sprite1.Size.Height < sprite2.Location.Y);
        }

        public static bool CollisionLeft(Sprite sprite1, Sprite sprite2)
        {
            return !(sprite1.Location.X > sprite2.Location.X + sprite2.Size.Width);
        }

        public static bool CollisionRight(Sprite sprite1, Sprite sprite2)
        {
            return !(sprite1.Location.X + sprite1.Size.Width < sprite2.Location.X);
        }
    }
}