﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace ForagingJoe
{
    public class EnemySprite : Sprite
    {
        public const int Width = 32;
        public const int Height = 32;

        public const string _enemyBitmap = @"graphics\Enemy.bmp";

        public EnemySprite(GameState gameState, float x, float y)
            : base(gameState, x, y, _enemyBitmap)
        {
        }
    }

    public class Enemy : GameObject
    {
        // We'll have the enemies move at a consistent speed
        //private const float _initialSpeed = 30;
        private static PointF _initialDirection = new PointF(-1, 0);
        private const EnemyMovement _initialMovement = EnemyMovement.Left;
        //private const float _maximumSpeed = 200;
        //private const int _numberAliensX = 11;
        //private const int _numberAliensY = 5;
        //private const int _maxEnemies = _numberAliensX * _numberAliensY;
        //private const int _startY = 55;

        private List<Sprite> _enemies = new List<Sprite>();
        private PointF _direction;
        private float _speed = 100;
        private EnemyMovement _movement = _initialMovement;
        //private EnemyMovement _nextMovement;
        //private float _verticalResetPosition;
        private GameState _gameState;
        private Random _random = new Random();
        private const float _gravityModifier = 75.0f;

        public Enemy(GameState gameState)
        {
            _gameState = gameState;

            
            CreateEnemies();
        }

        public void CreateEnemies()
        {
            _enemies.Clear();

            _enemies.Add(new EnemySprite(_gameState, _gameState.GameArea.Width / 2 - 20, _gameState.GameArea.Height - 46));

            _direction = _initialDirection;
            //_speed = _initialSpeed;
            _movement = _initialMovement;
        }

        public override void Update(double gameTime, double deltaTime)
        {
            //Update each enemy in the collection. As we walk the list we get
            //the min and max positions of the updated enemies We will use the
            //limits to decide when the edge of the enemies group hits the edge
            //of the screen
            PointF minLocation = new PointF(Single.MaxValue, Single.MaxValue);
            PointF maxLocation = new PointF(Single.MinValue, Single.MinValue);

            //Set the speed based on the number of enemies
            //_speed = calculateSpeed(_aliens.Count);

            //Update each enemy
            foreach (Sprite sprite in _enemies)
            {
                minLocation = PointFMath.Min(sprite.Location, minLocation);
                maxLocation = PointFMath.Max(sprite.Location, maxLocation);


                sprite.Velocity = new PointF(_direction.X * _speed, _direction.Y * _speed);

                // enemies are affected by gravity
                sprite.Velocity.Y += ((float)_gameState.gravity * (float)deltaTime) * _gravityModifier;
               

                sprite.Update(gameTime, deltaTime);

                // limit enemy to on screen
                if (sprite.Location.Y < 0) sprite.Location.Y = 0;
                if (sprite.Location.Y > _gameState.GameArea.Height - EnemySprite.Height) sprite.Location.Y = _gameState.GameArea.Height - EnemySprite.Height;
            }

            //Set up the direction for the next frame
            switch (_movement)
            {
                case EnemyMovement.Left:
                case EnemyMovement.Right:
                    // If we have hit the edge of the screen we are moving towards
                    if ((minLocation.X < 0 && _movement == EnemyMovement.Left)
                        ||
                        (maxLocation.X + EnemySprite.Width > _gameState.GameArea.Width && _movement == EnemyMovement.Right))
                    {

                        // Then we reverse direction
                        _movement = (_movement == EnemyMovement.Left) ? EnemyMovement.Right : EnemyMovement.Left;

                        if (_movement == EnemyMovement.Left)
                        {
                            _direction.X = -1;
                            _direction.Y = 0;
                        }
                        else
                        {
                            _direction.X = 1;
                            _direction.Y = 0;
                        }
                    }
                    break;
            }

            
        }

        

        public override void Draw(Graphics graphics)
        {
            // Render each enemy
            foreach (Sprite sprite in _enemies)
            {
                sprite.Draw(graphics);
            }
        }

        public void Remove(Sprite enemy)
        {
            _enemies.Remove(enemy);
        }

        public Sprite CheckCollisions(Sprite collider)
        {
            //Search for any enemies that collide with the passed in sprite
            foreach (Sprite sprite in _enemies)
            {
                if (Sprite.Collision(collider, sprite))
                {
                    return sprite;
                }
            }
            return null;

        }

        public int Count
        {
            get
            {
                return _enemies.Count;
            }
        }

        private enum EnemyMovement
        {
            Left,
            Right,
            Down
        }
    }

}
